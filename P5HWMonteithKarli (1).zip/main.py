#math quiz with addition and subtraction

 # 11//29/2023

 # CTI-110 P5HW - Math Quiz

 #Karli Monteith
import random

def generate_numbers():
    """Generate two random numbers between 1 and 100."""
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    return num1, num2

def add_numbers(num1, num2):
    """Add two numbers and return the result."""
    return num1 + num2

def subtract_numbers(num1, num2):
    """Subtract num2 from num1 and return the result."""
    return num1 - num2

def display_menu():
    """Display the menu options."""
    print("MENU")
    print("1. Add the numbers and guess the result")
    print("2. Subtract the numbers and guess the result")
    print("3. Exit")

def main():
    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == "1":
            num1, num2 = generate_numbers()
            result = add_numbers(num1, num2)
            guess = int(input(f"What do you think {num1} + {num2} equals? "))
            if guess == result:
                print("Congratulations! You guessed it right!")
            else:
                print(f"Sorry, the correct answer is {result}.")

        elif choice == "2":
            num1, num2 = generate_numbers()
            result = subtract_numbers(num1, num2)
            guess = int(input(f"What do you think {num1} - {num2} equals? "))
            if guess == result:
                print("Congratulations! You guessed it right!")
            else:
                print(f"Sorry, the correct answer is {result}.")

        elif choice == "3":
          print("Goodbye")
          break

        else:
            print("Error: Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()